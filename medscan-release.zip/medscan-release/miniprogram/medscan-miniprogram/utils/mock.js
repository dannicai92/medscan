const MOCK_BOXES = [
  { id: 1, name: '我的药箱' },
  { id: 2, name: '外婆药箱' },
]

const MOCK_DRUGS = [
  { id: 1, boxId: 1, name: '布洛芬缓释胶囊',  expiry: '2026-08-15', scan_time: '2026-04-24 08:12' },
  { id: 2, boxId: 1, name: '感冒灵颗粒',       expiry: '2026-04-28', scan_time: '2026-04-23 18:44' },
  { id: 3, boxId: 1, name: '维生素C片',         expiry: '2026-04-20', scan_time: '2026-04-22 10:05' },
  { id: 4, boxId: 1, name: '复方氨酚烷胺片',    expiry: '2027-03-01', scan_time: '2026-04-21 09:30' },
  { id: 5, boxId: 2, name: '阿莫西林胶囊',      expiry: '2025-12-10', scan_time: '2026-04-20 14:00' },
  { id: 6, boxId: 2, name: '盐酸二甲双胍片',    expiry: '2026-09-30', scan_time: '2026-04-19 07:20' },
  { id: 7, boxId: 2, name: '硝酸甘油片',        expiry: '2026-04-25', scan_time: '2026-04-18 11:00' },
]

module.exports = { MOCK_BOXES, MOCK_DRUGS }
