// ════════════════════════════════════════════
// API LAYER — 接入真实后端时只需修改顶部配置
// ════════════════════════════════════════════

const API_CONFIG = {
  // ⚙️ 填入后端同伴电脑的局域网 IP，端口固定 8000
  // 例如: BASE_URL: 'http://192.168.1.100:8000'
  BASE_URL:      null,   // null = 使用 mock 数据
  POLL_INTERVAL: 3000,   // 无 WebSocket 时的轮询间隔（毫秒）
}

function wsUrl() {
  if (!API_CONFIG.BASE_URL) return null
  return API_CONFIG.BASE_URL.replace(/^http/, 'ws') + '/ws'
}

function request(method, path, data) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: `${API_CONFIG.BASE_URL}${path}`,
      method,
      data,
      header: { 'Content-Type': 'application/json' },
      success: (res) => resolve(res.data),
      fail: (err) => reject(err),
    })
  })
}

// ── 获取药品列表 ──────────────────────────────────────────────────────────────
async function fetchDrugs(boxId) {
  if (!API_CONFIG.BASE_URL) return null
  try {
    const data = await request('GET', '/api/v1/medicines?limit=200')
    return data.map(d => ({
      id:        d.id,
      boxId:     boxId,
      name:      d.medicine_name,
      expiry:    d.expiration_date,
      scan_time: d.created_at || '',
    }))
  } catch (e) {
    console.warn('[API] fetchDrugs failed, using mock:', e)
    return null
  }
}

// ── 手动录入药品 ──────────────────────────────────────────────────────────────
async function postDrug(drug) {
  if (!API_CONFIG.BASE_URL) return null
  try {
    const data = await request('POST', '/api/v1/medicines', {
      medicine_name:   drug.name,
      expiration_date: drug.expiry_date,
      gtin:            drug.gtin || null,
      lot:             drug.lot  || null,
    })
    return data.id
  } catch (e) {
    console.warn('[API] postDrug failed:', e)
    return null
  }
}

// ── 删除药品 ──────────────────────────────────────────────────────────────────
async function deleteDrug(id) {
  if (!API_CONFIG.BASE_URL) return
  try {
    await request('DELETE', `/api/v1/medicines/${id}`)
  } catch (e) {
    console.warn('[API] deleteDrug failed (local delete still applied):', e)
  }
}

// ── 扫描记录（轮询备用）──────────────────────────────────────────────────────
async function fetchLatestScans(limit) {
  if (!API_CONFIG.BASE_URL) return null
  try {
    return await request('GET', `/api/v1/scans?limit=${limit || 5}`)
  } catch (e) {
    console.warn('[API] fetchLatestScans failed:', e)
    return null
  }
}

// ── 健康检查 ──────────────────────────────────────────────────────────────────
async function healthCheck() {
  if (!API_CONFIG.BASE_URL) return false
  try {
    const data = await request('GET', '/health')
    return data.ok === true
  } catch (e) {
    return false
  }
}

// ── 事件推送：优先 WebSocket，失败自动降级轮询 ───────────────────────────────
let _lastScanId = null
let _pollTimer  = null
let _socketTask = null

function initWebSocket(onMessage) {
  if (!API_CONFIG.BASE_URL) return
  _connectWS(onMessage)
}

function _connectWS(onMessage) {
  const url = wsUrl()
  _socketTask = wx.connectSocket({ url, fail: () => _startPolling(onMessage) })

  _socketTask.onOpen(() => {
    console.log('[WS] 已连接')
    wx.showToast({ title: '已连接药箱', icon: 'success', duration: 1500 })
    if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null }
  })

  _socketTask.onMessage((res) => {
    try {
      onMessage(JSON.parse(res.data))
    } catch (e) {
      console.warn('[WS] 消息解析失败:', e)
    }
  })

  _socketTask.onClose(() => {
    console.warn('[WS] 断开，降级为轮询')
    _socketTask = null
    _startPolling(onMessage)
  })

  _socketTask.onError(() => {
    _socketTask = null
    _startPolling(onMessage)
  })
}

function _startPolling(onMessage) {
  if (_pollTimer || _socketTask) return
  console.log('[Poll] 开始轮询 /api/v1/scans')

  _pollTimer = setInterval(async () => {
    const scans = await fetchLatestScans(3)
    if (!scans || scans.length === 0) return
    const latest = scans[0]
    if (_lastScanId === null) { _lastScanId = latest.id; return }
    if (latest.id > _lastScanId) {
      _lastScanId = latest.id
      const p = latest.payload_json || {}
      onMessage({
        action:         'take_out',
        name:           p.medicine_name || latest.raw_code || '未知药品',
        expiry_date:    latest.expiration_date || p.expiration_date || null,
        box_id:         1,
        status:         latest.status,
        days_remaining: p.days_remaining,
      })
    }
  }, API_CONFIG.POLL_INTERVAL)
}

module.exports = {
  API_CONFIG,
  fetchDrugs,
  postDrug,
  deleteDrug,
  fetchLatestScans,
  healthCheck,
  initWebSocket,
}
