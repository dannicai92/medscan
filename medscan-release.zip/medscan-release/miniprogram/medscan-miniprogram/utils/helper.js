// ── 日期工具 ──
function daysFrom(dateStr) {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return Math.ceil((new Date(dateStr) - today) / 86400000)
}

function getStatus(dateStr) {
  const d = daysFrom(dateStr)
  if (d < 0)  return 'expired'
  if (d <= 7) return 'expiring'
  return 'normal'
}

function getExpiryText(dateStr) {
  const d = daysFrom(dateStr)
  if (d < 0)  return `已过期 ${Math.abs(d)} 天`
  if (d === 0) return '今天到期'
  if (d <= 7) return `还剩 ${d} 天到期`
  return `有效期至 ${dateStr}`
}

function getStatusLabel(s) {
  if (s === 'expired')  return '已过期'
  if (s === 'expiring') return '临期'
  return '有效'
}

function getStatusFace(s) {
  if (s === 'expired')  return '😢'
  if (s === 'expiring') return '😐'
  return '😊'
}

module.exports = { daysFrom, getStatus, getExpiryText, getStatusLabel, getStatusFace }
