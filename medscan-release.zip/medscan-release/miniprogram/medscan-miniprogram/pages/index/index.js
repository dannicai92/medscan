// pages/index/index.js
const { fetchDrugs, postDrug, deleteDrug, initWebSocket, API_CONFIG } = require('../../utils/api')
const { getStatus, getExpiryText, getStatusLabel, getStatusFace } = require('../../utils/helper')
const { MOCK_BOXES, MOCK_DRUGS } = require('../../utils/mock')

// 本地可变副本（mock 模式下直接操作）
let _drugs = MOCK_DRUGS.map(d => ({ ...d }))

Page({

  data: {
    // 药箱
    boxes:       [],
    activeBoxId: 1,
    // 药品
    allDrugs:      [],
    filteredDrugs: [],
    // 搜索/筛选
    searchQuery:  '',
    activeFilter: 'all',
    filterOpen:   false,
    // 概览
    summary: { normal: 0, expiring: 0, expired: 0 },
    // 模式开关
    isTakeMode: false,
    // 通知弹窗
    notifVisible: false,
    notif: {},
  },

  // ── 生命周期 ──
  async onLoad() {
    // 加载药品（服务器或 mock）
    const serverDrugs = await fetchDrugs(this.data.activeBoxId)
    if (serverDrugs) {
      _drugs = serverDrugs
    }
    this._refresh()
    initWebSocket(this._onHardwareEvent.bind(this))
  },

  // ── 内部：刷新所有渲染数据 ──
  _refresh() {
    const { activeBoxId, searchQuery, activeFilter } = this.data

    // 药箱列表（标记是否有过期药）
    const boxes = MOCK_BOXES.map(b => ({
      ...b,
      hasExpired: _drugs.some(d => d.boxId === b.id && getStatus(d.expiry) === 'expired'),
    }))

    // 当前药箱药品
    let list = _drugs.filter(d => d.boxId === activeBoxId)

    // 概览统计
    const summary = {
      normal:   list.filter(d => getStatus(d.expiry) === 'normal').length,
      expiring: list.filter(d => getStatus(d.expiry) === 'expiring').length,
      expired:  list.filter(d => getStatus(d.expiry) === 'expired').length,
    }

    // 搜索
    if (searchQuery) {
      list = list.filter(d => d.name.includes(searchQuery))
    }
    // 筛选
    if (activeFilter !== 'all') {
      list = list.filter(d => getStatus(d.expiry) === activeFilter)
    }
    // 排序（最快到期在前）
    list.sort((a, b) => new Date(a.expiry) - new Date(b.expiry))

    // 加入显示字段
    const filteredDrugs = list.map(d => {
      const s = getStatus(d.expiry)
      return {
        ...d,
        status:      s,
        expiryText:  getExpiryText(d.expiry),
        statusLabel: getStatusLabel(s),
        face:        getStatusFace(s),
      }
    })

    this.setData({ boxes, summary, filteredDrugs })
  },

  // ── 药箱切换 ──
  onSelectBox(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ activeBoxId: id, searchQuery: '', activeFilter: 'all', filterOpen: false })
    this._refresh()
  },

  // ── 搜索 ──
  onSearch(e) {
    this.setData({ searchQuery: e.detail.value })
    this._refresh()
  },

  // ── 筛选 ──
  toggleFilter() {
    this.setData({ filterOpen: !this.data.filterOpen })
  },
  onFilter(e) {
    this.setData({ activeFilter: e.currentTarget.dataset.f })
    this._refresh()
  },

  // ── 模式开关 ──
  onModeChange(e) {
    const isTakeMode = e.detail.value
    this.setData({ isTakeMode })
    wx.showToast({
      title: isTakeMode ? '📤 取出模式' : '📥 放入模式',
      icon: 'none',
      duration: 1200,
    })
  },

  // ── 药品卡片点击 ──
  onDrugTap(e) {
    const { id, status } = e.currentTarget.dataset
    if (!this.data.isTakeMode) {
      wx.showToast({ title: '✅ 药品已录入，库存已更新', icon: 'none', duration: 1500 })
      return
    }
    const drug = _drugs.find(d => d.id === id)
    if (drug) this._showNotif(drug)
  },

  // ── 长按删除 ──
  onDrugLongPress(e) {
    const { id, name } = e.currentTarget.dataset
    wx.showActionSheet({
      itemList: ['删除此药品'],
      itemColor: '#E05252',
      success: (res) => {
        if (res.tapIndex === 0) {
          wx.showModal({
            title: '确认删除',
            content: `确定删除「${name}」吗？`,
            confirmColor: '#E05252',
            success: async (r) => {
              if (!r.confirm) return
              // 从本地数组删除
              const idx = _drugs.findIndex(d => d.id === id)
              if (idx !== -1) _drugs.splice(idx, 1)
              // 同步到服务器
              await deleteDrug(id)
              this._refresh()
              wx.showToast({ title: '已删除', icon: 'success', duration: 1200 })
            }
          })
        }
      }
    })
  },

  // ── 弹出通知 ──
  _showNotif(drug) {
    const s = getStatus(drug.expiry)
    this.setData({
      notifVisible: true,
      notif: {
        type:       s === 'expired' ? 'bad' : 'ok',
        name:       drug.name,
        expiryText: getExpiryText(drug.expiry),
      },
    })
  },

  // ── 关闭通知 ──
  closeNotif() {
    this.setData({ notifVisible: false })
  },
  onOverlayTap() {
    this.setData({ notifVisible: false })
  },

  // ── 关心动作 ──
  onCareWechat() {
    // 跳转微信（小程序内打开微信聊天）
    wx.openCustomerServiceChat({
      extInfo: { url: '' },
      corpId: '',
      fail: () => {
        // 降级：复制关心话术
        wx.setClipboardData({
          data: `亲爱的家人，我看到你刚刚取药了，记得按时服药哦，身体要紧！💊`,
          success: () => wx.showToast({ title: '关心话术已复制，可发给家人', icon: 'none', duration: 2000 }),
        })
      },
    })
    this.setData({ notifVisible: false })
  },

  onCarePhone() {
    wx.makePhoneCall({
      phoneNumber: '', // TODO: 接入联系人后填写
      fail: () => wx.showToast({ title: '请在通讯录中拨打家人电话', icon: 'none' }),
    })
    this.setData({ notifVisible: false })
  },

  onCareLater() {
    this.setData({ notifVisible: false })
    wx.showToast({ title: '已记录，待跟进', icon: 'none', duration: 1500 })
  },

  // ── 硬件事件处理（WebSocket 推送） ──
  // ⚙️ 接入硬件后，所有扫描事件走这里，无需手动拨开关
  _onHardwareEvent(payload) {
    const { action, name, expiry_date, box_id } = payload

    if (action === 'put_in') {
      // 放入：录入药品
      const newDrug = {
        id:        _drugs.length ? Math.max(..._drugs.map(d => d.id)) + 1 : 1,
        boxId:     box_id,
        name,
        expiry:    expiry_date,
        scan_time: new Date().toLocaleString('zh-CN'),
      }
      _drugs.push(newDrug)
      // 同步到服务器
      postDrug({ name, expiry_date, box_id, scan_time: newDrug.scan_time })
      this._refresh()
      wx.showToast({ title: `✅ 已录入：${name}`, icon: 'none', duration: 1500 })

    } else if (action === 'take_out') {
      // 取出：弹通知
      let drug = _drugs.find(d => d.boxId === box_id && d.name === name)
      if (!drug) {
        // 没有已录入记录，用推送数据临时构建
        drug = { id: -1, boxId: box_id, name, expiry: expiry_date, scan_time: '' }
      }
      this._showNotif(drug)
    }
  },

})
