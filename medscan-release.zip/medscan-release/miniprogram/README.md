# MedScan S 微信小程序

## 目录结构

```
medscan-miniprogram/
├── app.js / app.json / app.wxss
├── pages/index/          # 主页面（药箱列表+扫描通知）
└── utils/
    ├── api.js            # ⚙️ 接入后端只改这里
    ├── helper.js         # 日期工具
    └── mock.js           # Mock 数据
```

## 本地运行

1. 下载微信开发者工具
2. 注册小程序测试号，获取 AppID（developers.weixin.qq.com/sandbox）
3. 开发者工具 → 导入项目 → 选本目录 → 填入 AppID → 编译

## ⚙️ 接入后端（只改一行）

打开 `utils/api.js`，修改第8行：

```js
BASE_URL: 'http://192.168.x.x:8000',  // ← 后端同伴电脑的局域网 IP
```

后端端口固定是 **8000**（不是8080）。

## 后端接口说明（已由后端同伴实现）

| 方法 | 路径 | 作用 |
|---|---|---|
| GET  | /health | 健康检查 |
| GET  | /api/v1/medicines | 获取药品库列表 |
| POST | /api/v1/medicines | 手动录入药品 |
| GET  | /api/v1/scans | 扫描记录（前端轮询用） |
| POST | /api/v1/upload | ESP32上传图片（硬件调用） |

## 工作原理

- 前端每3秒轮询一次 `/api/v1/scans`
- 发现新记录（id增大）→ 弹出取药通知
- status 为 `expired` → 红色哭脸；其余 → 绿色笑脸

## 注意

- 开发者工具调试时勾选「不校验合法域名」
- 同一 WiFi 下联调
