App({
  globalData: {
    wsConnected: false,
    socketTask: null,
  },
  onLaunch() {},
})
