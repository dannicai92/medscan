from __future__ import annotations

import platform
import sys
import unittest
from datetime import datetime
from io import StringIO
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from server.bootstrap import bootstrap_local_vendor  # noqa: E402
from server.config import settings  # noqa: E402

bootstrap_local_vendor()


def main() -> int:
    settings.reports_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    report_path = settings.reports_dir / f"test-report-{timestamp}.txt"
    latest_path = settings.reports_dir / "latest-test-report.txt"

    stream = StringIO()
    stream.write("ESP32 药箱识别服务测试报告\n")
    stream.write(f"生成时间: {datetime.now().isoformat(timespec='seconds')}\n")
    stream.write(f"Python: {sys.version.split()[0]}\n")
    stream.write(f"Platform: {platform.platform()}\n")
    stream.write(f"Project: {PROJECT_ROOT}\n")
    stream.write("Command: python scripts/run_tests.py\n")
    stream.write("\n")

    suite = unittest.defaultTestLoader.discover(
        start_dir=str(PROJECT_ROOT / "tests"),
        pattern="test*.py",
    )
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    output = stream.getvalue()

    report_path.write_text(output, encoding="utf-8")
    latest_path.write_text(output, encoding="utf-8")

    print(output)
    print(f"测试报告已保存: {report_path}")
    print(f"最新报告快捷文件: {latest_path}")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
