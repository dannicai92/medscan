from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from server.bootstrap import bootstrap_local_vendor  # noqa: E402
from server.config import settings  # noqa: E402
from server.ocr import ExpirationOCR  # noqa: E402

bootstrap_local_vendor()


def main() -> int:
    parser = argparse.ArgumentParser(description="使用 OCR 尝试识别药盒上的有效期或生产日期")
    parser.add_argument("image", help="要测试的图片路径")
    parser.add_argument("--output", help="指定 JSON 结果文件路径，默认写入 reports 目录")
    args = parser.parse_args()

    image_path = Path(args.image).expanduser().resolve()
    if not image_path.exists():
        print(f"图片不存在: {image_path}", file=sys.stderr)
        return 2

    settings.reports_dir.mkdir(parents=True, exist_ok=True)
    image_bytes = image_path.read_bytes()

    payload = ExpirationOCR().inspect(image_bytes)
    payload["ok"] = payload.get("available", False)
    payload["source_image"] = str(image_path)
    payload["tested_at"] = datetime.now().isoformat(timespec="seconds")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    output_path = Path(args.output).expanduser().resolve() if args.output else settings.reports_dir / f"ocr-test-{timestamp}.json"
    latest_path = settings.reports_dir / "latest-ocr-test.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    encoded = json.dumps(payload, ensure_ascii=False, indent=2)
    output_path.write_text(encoded, encoding="utf-8")
    latest_path.write_text(encoded, encoding="utf-8")

    print(encoded)
    print(f"OCR 测试结果已保存: {output_path}")
    print(f"最新 OCR 测试快捷文件: {latest_path}")
    return 0 if payload.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
