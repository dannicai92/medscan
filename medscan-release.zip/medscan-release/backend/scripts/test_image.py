from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from server.app import repository, scan_service  # noqa: E402
from server.bootstrap import bootstrap_local_vendor  # noqa: E402
from server.config import settings  # noqa: E402
from server.ocr import ExpirationOCR  # noqa: E402

bootstrap_local_vendor()


def main() -> int:
    parser = argparse.ArgumentParser(description="使用本地图片测试条码识别，可选追加 OCR")
    parser.add_argument("image", nargs="?", help="要测试的图片路径，例如 .\\samples\\drug.jpg")
    parser.add_argument("--device-id", default="local-image-test", help="写入扫描记录的设备编号")
    parser.add_argument("--manual-code", help="调试用：跳过图片识别，直接使用手动追溯码")
    parser.add_argument("--no-save-upload", action="store_true", help="不把测试图片复制到 uploads 目录")
    parser.add_argument("--output", help="指定 JSON 结果文件路径，默认写入 reports 目录")
    parser.add_argument("--with-ocr", action="store_true", help="额外执行 OCR，尝试识别有效期或生产日期")
    args = parser.parse_args()

    image_path = Path(args.image).expanduser().resolve() if args.image else None
    if image_path and not image_path.exists():
        print(f"图片不存在: {image_path}", file=sys.stderr)
        return 2
    if not image_path and not args.manual_code:
        print("请提供图片路径，或使用 --manual-code 提供追溯码。", file=sys.stderr)
        return 2

    repository.init_database()
    settings.reports_dir.mkdir(parents=True, exist_ok=True)

    image_bytes = image_path.read_bytes() if image_path else b""
    status_code, payload = scan_service.analyze(
        image_bytes=image_bytes,
        original_filename=image_path.name if image_path else "manual-code.txt",
        device_id=args.device_id,
        manual_code=args.manual_code,
        save_upload=not args.no_save_upload,
    )
    payload["http_status_code"] = status_code
    payload["source_image"] = str(image_path) if image_path else None
    payload["tested_at"] = datetime.now().isoformat(timespec="seconds")
    if args.with_ocr and image_path:
        payload["ocr"] = ExpirationOCR().inspect(image_bytes)

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    output_path = Path(args.output).expanduser().resolve() if args.output else settings.reports_dir / f"image-test-{timestamp}.json"
    latest_path = settings.reports_dir / "latest-image-test.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    encoded = json.dumps(payload, ensure_ascii=False, indent=2)
    output_path.write_text(encoded, encoding="utf-8")
    latest_path.write_text(encoded, encoding="utf-8")

    print(encoded)
    print(f"图片测试结果已保存: {output_path}")
    print(f"最新图片测试快捷文件: {latest_path}")
    return 0 if payload.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
