from datetime import datetime
from pathlib import Path
from unittest import TestCase

from server.scan_service import build_dated_upload_path


class ScanServicePathTests(TestCase):
    def test_build_dated_upload_path_uses_date_directory_and_timestamp_filename(self) -> None:
        now = datetime(2026, 4, 24, 18, 30, 45, 123456)

        target = build_dated_upload_path(Path("uploads"), "photo.jpg", now=now)

        self.assertEqual(target.parent, Path("uploads") / "20260424")
        self.assertEqual(target.suffix, ".jpg")
        self.assertTrue(target.name.startswith("20260424-183045-123456_"))
