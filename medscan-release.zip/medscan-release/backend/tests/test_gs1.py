from datetime import date
from unittest import TestCase

from server.gs1 import extract_expiration_date, parse_gs1_datamatrix, to_friendly_fields


class GS1ParserTests(TestCase):
    def test_parse_linear_datamatrix(self) -> None:
        raw_code = "01012345678901281726123110LOT123\x1d21SERIAL999"

        ai_values = parse_gs1_datamatrix(raw_code)

        self.assertEqual(ai_values["01"], "01234567890128")
        self.assertEqual(ai_values["17"], "261231")
        self.assertEqual(ai_values["10"], "LOT123")
        self.assertEqual(ai_values["21"], "SERIAL999")
        self.assertEqual(extract_expiration_date(ai_values), date(2026, 12, 31))

    def test_parse_bracketed_datamatrix(self) -> None:
        raw_code = "(01)06912345678901(17)260430(10)BATCH01(21)ABC123"

        ai_values = parse_gs1_datamatrix(raw_code)
        friendly = to_friendly_fields(ai_values)

        self.assertEqual(ai_values["01"], "06912345678901")
        self.assertEqual(friendly["gtin"], "06912345678901")
        self.assertEqual(friendly["lot"], "BATCH01")
        self.assertEqual(extract_expiration_date(ai_values), date(2026, 4, 30))
