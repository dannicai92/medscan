from unittest import TestCase

from server.ocr import OCRLine, analyze_ocr_lines, extract_dates_from_text


class OCRParserTests(TestCase):
    def test_extract_full_date(self) -> None:
        dates = extract_dates_from_text("有效期至 2026.04.30")

        self.assertEqual([item.isoformat() for item in dates], ["2026-04-30"])

    def test_extract_short_date_when_keyword_present(self) -> None:
        dates = extract_dates_from_text("EXP260430", allow_short=True)

        self.assertEqual([item.isoformat() for item in dates], ["2026-04-30"])

    def test_analyze_lines_prefers_expiration_over_production(self) -> None:
        lines = [
            OCRLine(text="生产日期 2024-05-01", score=0.99, variant="rgb_0", box=[[0, 0], [1, 0], [1, 1], [0, 1]]),
            OCRLine(text="有效期至 2026-04-30", score=0.98, variant="rgb_0", box=[[0, 0], [1, 0], [1, 1], [0, 1]]),
        ]

        result = analyze_ocr_lines(lines)

        self.assertEqual(result["expiration_date"], "2026-04-30")
        self.assertEqual(result["production_date"], "2024-05-01")
