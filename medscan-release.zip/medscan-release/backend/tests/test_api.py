from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase

from fastapi.testclient import TestClient

from server.app import app, repository


class APITests(TestCase):
    def setUp(self) -> None:
        self.temp_dir = TemporaryDirectory()
        self.original_database_path = repository.database_path
        repository.database_path = Path(self.temp_dir.name) / "test.db"
        repository.init_database()
        self.client = TestClient(app)

    def tearDown(self) -> None:
        self.client.close()
        repository.database_path = self.original_database_path
        self.temp_dir.cleanup()

    def test_registry_fallback_when_manual_code_has_no_expiration(self) -> None:
        create_response = self.client.post(
            "/api/v1/medicines",
            json={
                "medicine_name": "头孢克肟分散片",
                "expiration_date": "2026-05-30",
                "gtin": "06912345678901",
                "lot": "BATCH01",
                "serial": "ABC123",
            },
        )
        self.assertEqual(create_response.status_code, 200)

        upload_response = self.client.post(
            "/api/v1/upload",
            headers={
                "x-device-id": "esp32-test-01",
                "x-manual-code": "(01)06912345678901(10)BATCH01(21)ABC123",
            },
            content=b"",
        )

        self.assertEqual(upload_response.status_code, 200)
        payload = upload_response.json()
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["status"], "valid")
        self.assertEqual(payload["medicine_name"], "头孢克肟分散片")
        self.assertEqual(payload["expiration_source"], "registry")

    def test_trace_code_endpoint_accepts_json_payload(self) -> None:
        response = self.client.post(
            "/api/v1/trace-code",
            json={
                "trace_code": "83933720112426469417",
                "device_id": "esp32-cam-01",
            },
        )

        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["raw_code"], "83933720112426469417")
        self.assertEqual(payload["device_id"], "esp32-cam-01")
        self.assertEqual(payload["barcode_format"], "manual_code")
