from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase

import numpy as np
from PIL import Image

from server.datamatrix import BarcodeDecodeError, DataMatrixDecoder


class DataMatrixDecoderTests(TestCase):
    def test_decode_generated_datamatrix(self) -> None:
        from pylibdmtx.pylibdmtx import encode

        raw_code = "01012345678901281726123110LOT123\x1d21SERIAL999"
        encoded = encode(raw_code.encode("utf-8"))
        image = Image.frombytes("RGB", (encoded.width, encoded.height), encoded.pixels)
        buffer = BytesIO()
        image.save(buffer, format="PNG")

        result = DataMatrixDecoder().decode(buffer.getvalue())

        self.assertEqual(result.raw_code, raw_code)
        self.assertEqual(result.barcode_format, "DataMatrix")

    def test_decode_generated_code128(self) -> None:
        import zxingcpp

        raw_code = "83933720112426469417"
        barcode = zxingcpp.create_barcode(raw_code, zxingcpp.BarcodeFormat.Code128)
        rendered = zxingcpp.write_barcode_to_image(barcode, scale=4, add_hrt=True)
        image = Image.fromarray(np.asarray(rendered)).rotate(90, expand=True)
        buffer = BytesIO()
        image.save(buffer, format="PNG")

        result = DataMatrixDecoder().decode(buffer.getvalue())

        self.assertEqual(result.raw_code, raw_code)
        self.assertEqual(result.barcode_format, "Code 128")

    def test_decode_failure_writes_debug_crops_when_debug_dir_provided(self) -> None:
        image = Image.new("RGB", (200, 200), color="white")
        buffer = BytesIO()
        image.save(buffer, format="PNG")

        with TemporaryDirectory() as temp_dir:
            with self.assertRaises(BarcodeDecodeError) as context:
                DataMatrixDecoder().decode(buffer.getvalue(), debug_dir=Path(temp_dir))

            self.assertIn("datamatrix", context.exception.diagnostics)
            self.assertIn("linear", context.exception.diagnostics)
