# ESP32 药箱图片识别服务

这个服务用于接收 ESP32 上传的药品图片，识别图片里的条码，提取 GS1 字段，并判断药品是否过期。它现在既支持 `DataMatrix`，也支持药盒上常见的一维追溯码，例如 `Code 128`。另外还补了一套本地 OCR 测试链路，可以尝试从药盒图片里识别“有效期”“失效日期”“生产日期”等文字。

## 功能

- 接收 ESP32 上传的图片
- 识别 `DataMatrix`
- 识别药盒常见的一维追溯码，例如 `Code 128`
- 解析常见 GS1 AI 字段：`01`、`10`、`17`、`21`
- 优先使用条码中的有效期判断是否过期
- 如果条码里没有有效期，则查询本地药品库补全
- 支持独立 OCR 测试，尝试识别药盒上的日期文字
- 保存每次识别记录、原始图片和测试报告

## 目录

- `main.py`：启动入口
- `server/app.py`：HTTP API
- `server/scan_service.py`：识别、过期判断、扫描落库
- `server/datamatrix.py`：DataMatrix 和一维条码解码
- `server/gs1.py`：GS1 解析
- `server/ocr.py`：OCR 文本识别和日期提取
- `server/database.py`：SQLite 药品库和扫描记录
- `scripts/run_tests.py`：运行测试并生成测试报告
- `scripts/test_image.py`：用本地图片测试条码识别，可选追加 OCR
- `scripts/test_ocr.py`：只跑 OCR，检查图片里能识别到哪些文字和日期
- `tests/`：自动化测试
- `.vendor/`：本地 Python 依赖
- `reports/`：测试报告和本地图片测试结果

## 启动服务

```powershell
python main.py
```

服务默认监听 `0.0.0.0:8000`。

## API

### 1. 健康检查

```http
GET /health
```

### 2. 登记药品资料

```http
POST /api/v1/medicines
Content-Type: application/json
```

```json
{
  "medicine_name": "阿莫西林胶囊",
  "expiration_date": "2026-12-31",
  "gtin": "01234567890128",
  "lot": "LOT123",
  "serial": "SERIAL999",
  "manufacturer": "示例药厂"
}
```

### 3. 上传图片识别

支持两种方式：

#### 方式 A：ESP32 直接上传图片原始字节

```http
POST /api/v1/upload
Content-Type: image/jpeg
X-Device-Id: esp32-cam-01
```

请求体直接放 JPEG 或 PNG 二进制内容。

#### 方式 B：`multipart/form-data`

字段：

- `image`：图片文件
- `device_id`：设备编号，可选
- `manual_code`：调试时可手动传追溯码，可选

```powershell
curl.exe -X POST "http://127.0.0.1:8000/api/v1/upload" `
  -F "image=@test.png" `
  -F "device_id=esp32-cam-01"
```

## 自动化测试

运行测试并自动把结果写入 `reports/`：

```powershell
python scripts/run_tests.py
```

生成的文件：

- `reports/latest-test-report.txt`
- `reports/test-report-YYYYMMDD-HHMMSS-ffffff.txt`

## 本地图片测试

### 只测条码识别

```powershell
python scripts/test_image.py "D:\你的图片\drug.jpg"
```

### 条码识别同时追加 OCR

```powershell
python scripts/test_image.py "D:\你的图片\drug.jpg" --with-ocr
```

### 指定设备编号

```powershell
python scripts/test_image.py ".\samples\drug.jpg" --device-id esp32-cam-dev
```

### 不保存测试图片到 `uploads`

```powershell
python scripts/test_image.py ".\samples\drug.jpg" --no-save-upload
```

### 只测追溯码文本，不走图片识别

```powershell
python scripts/test_image.py --manual-code "(01)06912345678901(17)260430(10)BATCH01(21)ABC123"
```

本地图片测试会生成：

- `reports/latest-image-test.json`
- `reports/image-test-YYYYMMDD-HHMMSS-ffffff.json`

## 独立 OCR 测试

如果你想单独看看图片里 OCR 能读到什么文字，可以直接跑：

```powershell
python scripts/test_ocr.py "D:\你的图片\drug.jpg"
```

OCR 测试会生成：

- `reports/latest-ocr-test.json`
- `reports/ocr-test-YYYYMMDD-HHMMSS-ffffff.json`

OCR 结果里会包含：

- `texts`：识别到的文字列表
- `date_candidates`：识别到的日期候选
- `expiration_date`：只在命中“有效期/失效期/EXP”这类明确语义时才会给出
- `production_date`：命中“生产日期/MFG”等语义时给出

## 现实限制

- 如果药盒上是“码上放心追溯码”这类一维条码，服务能先把码值读出来，但这类码通常不直接携带有效期
- 如果图片里没有拍到盒身印刷的日期区域，OCR 也无法凭空判断过期时间
- 所以要稳定判断药品是否过期，最好至少满足这两种方式之一：
  - 本地药品库里已经登记了 `raw_code -> expiration_date`
  - 拍照时把盒身上的“有效期/失效日期”文字一起拍清楚

## 数据文件

- 扫描记录数据库：`data/pharma_trace.db`
- 上传图片目录：`uploads/`
- 测试和图片识别报告：`reports/`

## ESP32 对接建议

- 如果是 `ESP32-CAM`，建议直接 `HTTP POST` 图片原始字节，头里带 `X-Device-Id`
- 服务端返回的 `status` 可直接作为控制依据：
  - `valid`：可继续出药
  - `expired`：禁止出药
  - `unknown`：识别到了码，但缺少有效期
  - `decode_failed`：图片里没识别到可用条码
