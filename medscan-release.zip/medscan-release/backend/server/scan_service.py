from __future__ import annotations

import json
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any

from .config import settings
from .database import MedicineRepository
from .datamatrix import DataMatrixDecodeError, DataMatrixDecoder
from .gs1 import extract_expiration_date, parse_gs1_datamatrix, to_friendly_fields


class ScanService:
    def __init__(self, repository: MedicineRepository, decoder: DataMatrixDecoder) -> None:
        self.repository = repository
        self.decoder = decoder

    def analyze(
        self,
        *,
        image_bytes: bytes,
        original_filename: str = "",
        device_id: str | None = None,
        manual_code: str | None = None,
        save_upload: bool = True,
    ) -> tuple[int, dict[str, Any]]:
        manual_code = manual_code or None
        if not image_bytes and not manual_code:
            return 400, {
                "ok": False,
                "status": "bad_request",
                "expired": None,
                "message": "没有收到图片内容，也没有提供 manual_code。",
                "device_id": device_id,
                "upload_path": None,
            }

        upload_path = self.save_upload(original_filename, image_bytes) if image_bytes and save_upload else None
        debug_context = self.create_debug_session(
            image_bytes=image_bytes,
            original_filename=original_filename,
            upload_path=upload_path,
            device_id=device_id,
        )
        debug_dir = debug_context["artifact_dir"] if debug_context is not None else None

        try:
            decode_result = None if manual_code else self.decoder.decode(image_bytes, debug_dir=debug_dir)
            decoder_diagnostics = None if manual_code else decode_result.diagnostics
            raw_code = manual_code or decode_result.raw_code
            barcode_format = "manual_code" if manual_code else decode_result.barcode_format
            ai_values = parse_gs1_datamatrix(raw_code)
            friendly = to_friendly_fields(ai_values)
            expiration_date = extract_expiration_date(ai_values)
            medicine_record = self.repository.find_medicine(
                raw_code=raw_code,
                gtin=ai_values.get("01"),
                lot=ai_values.get("10"),
                serial=ai_values.get("21"),
            )

            if expiration_date is None and medicine_record and medicine_record.get("expiration_date"):
                expiration_date = date.fromisoformat(medicine_record["expiration_date"])
                expiration_source = "registry"
            elif expiration_date is not None:
                expiration_source = "barcode"
            else:
                expiration_source = None

            status, expired, days_remaining, message = evaluate_expiration(
                expiration_date,
                unknown_message=build_unknown_message(barcode_format, ai_values),
            )
            response_payload: dict[str, Any] = {
                "ok": True,
                "raw_code": raw_code,
                "device_id": device_id,
                "status": status,
                "expired": expired,
                "message": message,
                "engine": "manual_code" if manual_code else decode_result.engine,
                "barcode_format": barcode_format,
                "barcode_family": classify_barcode_family(barcode_format),
                "expiration_date": expiration_date.isoformat() if expiration_date else None,
                "days_remaining": days_remaining,
                "expiration_source": expiration_source,
                "medicine_name": medicine_record["medicine_name"] if medicine_record else None,
                "registry_hit": medicine_record is not None,
                "parsed_fields": {
                    "ai_values": ai_values,
                    "friendly": friendly,
                },
                "upload_path": str(upload_path) if upload_path else None,
            }

            self.attach_debug_metadata(
                response_payload=response_payload,
                debug_context=debug_context,
                decoder_diagnostics=decoder_diagnostics,
            )

            record_id = self.repository.log_scan(
                device_id=device_id,
                raw_code=raw_code,
                upload_path=str(upload_path) if upload_path else None,
                status=status,
                expiration_date=expiration_date,
                payload=response_payload,
                message=message,
            )
            response_payload["record_id"] = record_id

            if debug_context is not None:
                report_path = self.write_debug_report(
                    debug_context=debug_context,
                    response_payload=response_payload,
                    decoder_diagnostics=decoder_diagnostics,
                    error=None,
                )
                response_payload["debug"]["report_path"] = str(report_path)

            return 200, response_payload

        except DataMatrixDecodeError as exc:
            decoder_diagnostics = getattr(exc, "diagnostics", None)
            response_payload = {
                "ok": False,
                "status": "decode_failed",
                "expired": None,
                "message": str(exc),
                "device_id": device_id,
                "upload_path": str(upload_path) if upload_path else None,
            }
            self.attach_debug_metadata(
                response_payload=response_payload,
                debug_context=debug_context,
                decoder_diagnostics=decoder_diagnostics,
            )

            record_id = self.repository.log_scan(
                device_id=device_id,
                raw_code=None,
                upload_path=str(upload_path) if upload_path else None,
                status="decode_failed",
                expiration_date=None,
                payload=response_payload,
                message=str(exc),
            )
            response_payload["record_id"] = record_id

            if debug_context is not None:
                report_path = self.write_debug_report(
                    debug_context=debug_context,
                    response_payload=response_payload,
                    decoder_diagnostics=decoder_diagnostics,
                    error={"type": "decode_failed", "message": str(exc)},
                )
                response_payload["debug"]["report_path"] = str(report_path)

            return 422, response_payload

        except Exception as exc:  # pragma: no cover
            message = f"服务处理失败: {exc}"
            response_payload = {
                "ok": False,
                "status": "server_error",
                "expired": None,
                "message": message,
                "device_id": device_id,
                "upload_path": str(upload_path) if upload_path else None,
            }
            self.attach_debug_metadata(
                response_payload=response_payload,
                debug_context=debug_context,
                decoder_diagnostics=None,
            )

            record_id = self.repository.log_scan(
                device_id=device_id,
                raw_code=None,
                upload_path=str(upload_path) if upload_path else None,
                status="server_error",
                expiration_date=None,
                payload=response_payload,
                message=message,
            )
            response_payload["record_id"] = record_id

            if debug_context is not None:
                report_path = self.write_debug_report(
                    debug_context=debug_context,
                    response_payload=response_payload,
                    decoder_diagnostics=None,
                    error={"type": "server_error", "message": message},
                )
                response_payload["debug"]["report_path"] = str(report_path)

            return 500, response_payload

    def save_upload(self, filename: str, image_bytes: bytes) -> Path:
        target_path = build_dated_upload_path(settings.upload_dir, filename)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(image_bytes)
        return target_path

    def create_debug_session(
        self,
        *,
        image_bytes: bytes,
        original_filename: str,
        upload_path: Path | None,
        device_id: str | None,
    ) -> dict[str, Any] | None:
        if not image_bytes:
            return None

        suffix = Path(original_filename).suffix or ".jpg"
        session_id = f"{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}_{uuid.uuid4().hex[:8]}"
        artifact_dir = settings.debug_dir / session_id
        artifact_dir.mkdir(parents=True, exist_ok=True)

        input_image_path = artifact_dir / f"input{suffix}"
        input_image_path.write_bytes(image_bytes)
        return {
            "session_id": session_id,
            "artifact_dir": artifact_dir,
            "input_image_path": input_image_path,
            "upload_path": upload_path,
            "device_id": device_id,
        }

    def attach_debug_metadata(
        self,
        *,
        response_payload: dict[str, Any],
        debug_context: dict[str, Any] | None,
        decoder_diagnostics: dict[str, Any] | None,
    ) -> None:
        if debug_context is None:
            return

        response_payload["debug"] = {
            "artifact_dir": str(debug_context["artifact_dir"]),
            "input_image_path": str(debug_context["input_image_path"]),
            "upload_path": str(debug_context["upload_path"]) if debug_context["upload_path"] else None,
            "report_path": None,
            "decoder_summary": summarize_decoder_diagnostics(decoder_diagnostics),
        }

    def write_debug_report(
        self,
        *,
        debug_context: dict[str, Any],
        response_payload: dict[str, Any],
        decoder_diagnostics: dict[str, Any] | None,
        error: dict[str, Any] | None,
    ) -> Path:
        report_path = debug_context["artifact_dir"] / "scan-debug.json"
        debug_payload = {
            "session_id": debug_context["session_id"],
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "device_id": debug_context["device_id"],
            "input_image_path": str(debug_context["input_image_path"]),
            "upload_path": str(debug_context["upload_path"]) if debug_context["upload_path"] else None,
            "response": response_payload,
            "decoder_diagnostics": decoder_diagnostics,
            "error": error,
        }
        report_path.write_text(
            json.dumps(debug_payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return report_path


def summarize_decoder_diagnostics(decoder_diagnostics: dict[str, Any] | None) -> dict[str, Any] | None:
    if not decoder_diagnostics:
        return None

    datamatrix_attempts = decoder_diagnostics.get("datamatrix", {}).get("attempted_variants", [])
    linear_attempts = decoder_diagnostics.get("linear", {}).get("attempted_variants", [])
    regions = decoder_diagnostics.get("linear", {}).get("detected_regions", [])
    saved_artifacts = decoder_diagnostics.get("saved_artifacts", [])
    return {
        "image_size": decoder_diagnostics.get("image_size"),
        "datamatrix_attempt_count": len(datamatrix_attempts),
        "linear_attempt_count": len(linear_attempts),
        "detected_region_count": len(regions),
        "saved_artifact_count": len(saved_artifacts),
    }


def build_dated_upload_path(
    upload_root: Path,
    filename: str,
    now: datetime | None = None,
) -> Path:
    timestamp = now or datetime.now()
    date_key = timestamp.strftime("%Y%m%d")
    time_key = timestamp.strftime("%Y%m%d-%H%M%S-%f")
    suffix = Path(filename).suffix or ".jpg"
    target_name = f"{time_key}_{uuid.uuid4().hex[:8]}{suffix}"
    return upload_root / date_key / target_name


def classify_barcode_family(barcode_format: str | None) -> str | None:
    if not barcode_format:
        return None
    if barcode_format in {"DataMatrix", "QR Code", "Aztec", "PDF417"}:
        return "2d"
    if barcode_format == "manual_code":
        return "manual"
    return "1d"


def build_unknown_message(barcode_format: str | None, ai_values: dict[str, str]) -> str:
    if barcode_format not in {None, "manual_code", "DataMatrix"} and not ai_values:
        return (
            f"已识别到一维条码（{barcode_format}），但这类追溯码通常不直接携带有效期。"
            "请在本地药品库登记该 raw_code，或结合包装上的有效期文字/OCR 来判断。"
        )
    return "追溯码中未解析到有效期，且本地药品库没有命中。"


def evaluate_expiration(
    expiration_date: date | None,
    unknown_message: str | None = None,
) -> tuple[str, bool | None, int | None, str]:
    if expiration_date is None:
        return "unknown", None, None, unknown_message or "追溯码中未解析到有效期，且本地药品库没有命中。"

    today = date.today()
    days_remaining = (expiration_date - today).days
    if days_remaining < 0:
        return "expired", True, days_remaining, "药品已过期，请勿继续发药。"
    return "valid", False, days_remaining, "药品在有效期内。"
