from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    project_root: Path = Path(__file__).resolve().parents[1]
    data_dir: Path = project_root / "data"
    upload_dir: Path = project_root / "uploads"
    reports_dir: Path = project_root / "reports"
    debug_dir: Path = reports_dir / "debug_scans"
    database_path: Path = data_dir / "pharma_trace.db"
    host: str = os.getenv("SERVER_HOST", "0.0.0.0")
    port: int = int(os.getenv("SERVER_PORT", "8000"))


settings = Settings()
