from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from PIL import Image, ImageOps

from .bootstrap import bootstrap_local_vendor

bootstrap_local_vendor()

from pylibdmtx.pylibdmtx import decode as dmtx_decode  # noqa: E402

try:  # noqa: E402
    import zxingcpp
except ImportError:  # pragma: no cover
    zxingcpp = None


@dataclass(frozen=True)
class DecodeResult:
    raw_code: str
    engine: str
    barcode_format: str
    diagnostics: dict[str, Any] | None = None


class BarcodeDecodeError(RuntimeError):
    def __init__(self, message: str, diagnostics: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.diagnostics = diagnostics or {}


DataMatrixDecodeError = BarcodeDecodeError


class DataMatrixDecoder:
    def __init__(self) -> None:
        self.barcode_detector = cv2.barcode_BarcodeDetector()
        self.max_debug_crops = 16

    def decode(self, image_bytes: bytes, debug_dir: Path | None = None) -> DecodeResult:
        image = Image.open(BytesIO(image_bytes)).convert("RGB")
        diagnostics = {
            "image_size": {"width": image.width, "height": image.height},
            "datamatrix": {"attempted_variants": [], "decoded": False},
            "linear": {"attempted_variants": [], "decoded": False, "detected_regions": []},
            "saved_artifacts": [],
        }

        datamatrix_result = self._decode_datamatrix(image, diagnostics)
        if datamatrix_result is not None:
            return datamatrix_result

        linear_result = self._decode_linear_barcode(image, diagnostics, debug_dir)
        if linear_result is not None:
            return linear_result

        raise BarcodeDecodeError(
            "未识别到可用条码，请尽量拍正、拍近，并保证条码区域清晰完整。",
            diagnostics=diagnostics,
        )

    def _decode_datamatrix(
        self,
        image: Image.Image,
        diagnostics: dict[str, Any],
    ) -> DecodeResult | None:
        for variant_name, variant in self._build_datamatrix_variants(image):
            decoded_items = dmtx_decode(variant, timeout=200)
            diagnostics["datamatrix"]["attempted_variants"].append(
                {
                    "variant": variant_name,
                    "decoded": bool(decoded_items),
                }
            )
            if not decoded_items:
                continue

            decoded_text = decoded_items[0].data.decode("utf-8", errors="replace")
            diagnostics["datamatrix"]["decoded"] = True
            return DecodeResult(
                raw_code=decoded_text,
                engine="pylibdmtx",
                barcode_format="DataMatrix",
                diagnostics=diagnostics,
            )
        return None

    def _decode_linear_barcode(
        self,
        image: Image.Image,
        diagnostics: dict[str, Any],
        debug_dir: Path | None,
    ) -> DecodeResult | None:
        if zxingcpp is None:
            diagnostics["linear"]["zxing_available"] = False
            return None

        diagnostics["linear"]["zxing_available"] = True
        saved_crop_count = 0

        for variant_name, variant in self._build_linear_variants(image):
            result = self._read_linear_candidate(variant)
            diagnostics["linear"]["attempted_variants"].append(
                {
                    "variant": variant_name,
                    "direct_decode": result.raw_code if result is not None else None,
                }
            )
            if result is not None:
                diagnostics["linear"]["decoded"] = True
                return DecodeResult(
                    raw_code=result.raw_code,
                    engine=result.engine,
                    barcode_format=result.barcode_format,
                    diagnostics=diagnostics,
                )

            cropped_variants, region_infos, saved_crop_count = self._extract_barcode_regions(
                variant=variant,
                variant_name=variant_name,
                debug_dir=debug_dir,
                saved_crop_count=saved_crop_count,
                diagnostics=diagnostics,
            )
            diagnostics["linear"]["detected_regions"].extend(region_infos)

            for crop_name, cropped_variant in cropped_variants:
                cropped_result = self._read_linear_candidate(cropped_variant)
                if cropped_result is None:
                    continue
                diagnostics["linear"]["decoded"] = True
                diagnostics["linear"]["decoded_from_crop"] = crop_name
                return DecodeResult(
                    raw_code=cropped_result.raw_code,
                    engine=cropped_result.engine,
                    barcode_format=cropped_result.barcode_format,
                    diagnostics=diagnostics,
                )

        return None

    def _read_linear_candidate(self, candidate: np.ndarray) -> DecodeResult | None:
        results = zxingcpp.read_barcodes(candidate)
        if not results:
            return None

        barcode = next((item for item in results if item.valid and item.text), results[0])
        if not barcode.text:
            return None

        return DecodeResult(
            raw_code=barcode.text,
            engine="zxingcpp",
            barcode_format=str(barcode.format),
        )

    def _build_datamatrix_variants(self, image: Image.Image) -> list[tuple[str, np.ndarray]]:
        rgb = image.convert("RGB")
        grayscale = ImageOps.grayscale(rgb)

        rgb_array = np.asarray(rgb)
        gray_array = np.asarray(grayscale)
        thresholded = cv2.threshold(
            gray_array,
            0,
            255,
            cv2.THRESH_BINARY + cv2.THRESH_OTSU,
        )[1]
        enlarged = cv2.resize(
            gray_array,
            None,
            fx=2.0,
            fy=2.0,
            interpolation=cv2.INTER_CUBIC,
        )
        enlarged_thresholded = cv2.threshold(
            enlarged,
            0,
            255,
            cv2.THRESH_BINARY + cv2.THRESH_OTSU,
        )[1]

        return [
            ("rgb", rgb_array),
            ("gray", gray_array),
            ("thresh", thresholded),
            ("gray_2x", enlarged),
            ("thresh_2x", enlarged_thresholded),
        ]

    def _build_linear_variants(self, image: Image.Image) -> list[tuple[str, np.ndarray]]:
        variants: list[tuple[str, np.ndarray]] = []
        for angle in (0, 90, 180, 270):
            rotated = image.rotate(angle, expand=True).convert("RGB")
            rgb_array = np.asarray(rotated)
            gray_array = np.asarray(ImageOps.grayscale(rotated))
            thresholded = cv2.threshold(
                gray_array,
                0,
                255,
                cv2.THRESH_BINARY + cv2.THRESH_OTSU,
            )[1]
            enlarged = cv2.resize(
                rgb_array,
                None,
                fx=2.0,
                fy=2.0,
                interpolation=cv2.INTER_CUBIC,
            )
            variants.extend(
                [
                    (f"rgb_{angle}", rgb_array),
                    (f"gray_{angle}", gray_array),
                    (f"thresh_{angle}", thresholded),
                    (f"rgb_2x_{angle}", enlarged),
                ]
            )
        return variants

    def _extract_barcode_regions(
        self,
        *,
        variant: np.ndarray,
        variant_name: str,
        debug_dir: Path | None,
        saved_crop_count: int,
        diagnostics: dict[str, Any],
    ) -> tuple[list[tuple[str, np.ndarray]], list[dict[str, Any]], int]:
        try:
            _, _, _, points = self.barcode_detector.detectAndDecodeWithType(variant)
        except cv2.error:
            return [], [], saved_crop_count

        if points is None:
            return [], [], saved_crop_count

        source = self._ensure_color(variant)
        candidates: list[tuple[str, np.ndarray]] = []
        region_infos: list[dict[str, Any]] = []

        overlay_path = None
        if debug_dir is not None:
            overlay = source.copy()
            for quadrilateral in np.asarray(points):
                cv2.polylines(
                    overlay,
                    [np.asarray(quadrilateral, dtype=np.int32)],
                    isClosed=True,
                    color=(0, 255, 0),
                    thickness=2,
                )
            overlay_path = self._save_debug_image(debug_dir / f"{variant_name}_detected.png", overlay)
            diagnostics["saved_artifacts"].append(str(overlay_path))

        for region_index, quadrilateral in enumerate(np.asarray(points)):
            warped = self._warp_region(source, quadrilateral)
            if warped.size == 0:
                continue

            gray = cv2.cvtColor(warped, cv2.COLOR_RGB2GRAY)
            thresholded = cv2.threshold(
                gray,
                0,
                255,
                cv2.THRESH_BINARY + cv2.THRESH_OTSU,
            )[1]
            enlarged = cv2.resize(
                warped,
                None,
                fx=3.0,
                fy=3.0,
                interpolation=cv2.INTER_CUBIC,
            )

            region_variants = [
                (f"{variant_name}_region{region_index}_warped", warped),
                (f"{variant_name}_region{region_index}_rot90", cv2.rotate(warped, cv2.ROTATE_90_CLOCKWISE)),
                (f"{variant_name}_region{region_index}_gray", gray),
                (f"{variant_name}_region{region_index}_thresh", thresholded),
                (f"{variant_name}_region{region_index}_big", enlarged),
            ]
            candidates.extend(region_variants)

            artifact_paths: list[str] = []
            if debug_dir is not None:
                for crop_name, crop_variant in region_variants:
                    if saved_crop_count >= self.max_debug_crops:
                        break
                    crop_path = self._save_debug_image(debug_dir / f"{crop_name}.png", crop_variant)
                    artifact_paths.append(str(crop_path))
                    diagnostics["saved_artifacts"].append(str(crop_path))
                    saved_crop_count += 1

            region_infos.append(
                {
                    "variant": variant_name,
                    "region_index": region_index,
                    "points": np.asarray(quadrilateral, dtype=float).tolist(),
                    "overlay_path": str(overlay_path) if overlay_path is not None else None,
                    "crop_paths": artifact_paths,
                }
            )

        return candidates, region_infos, saved_crop_count

    @staticmethod
    def _ensure_color(variant: np.ndarray) -> np.ndarray:
        if variant.ndim == 3:
            return variant
        return cv2.cvtColor(variant, cv2.COLOR_GRAY2RGB)

    def _warp_region(self, source: np.ndarray, points: np.ndarray) -> np.ndarray:
        ordered = self._order_points(points)
        width = int(
            max(
                np.linalg.norm(ordered[1] - ordered[0]),
                np.linalg.norm(ordered[2] - ordered[3]),
            )
        )
        height = int(
            max(
                np.linalg.norm(ordered[3] - ordered[0]),
                np.linalg.norm(ordered[2] - ordered[1]),
            )
        )
        if width <= 0 or height <= 0:
            return np.empty((0, 0), dtype=np.uint8)

        destination = np.array(
            [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
            dtype=np.float32,
        )
        matrix = cv2.getPerspectiveTransform(ordered, destination)
        return cv2.warpPerspective(source, matrix, (width, height))

    @staticmethod
    def _order_points(points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=np.float32)
        sums = points.sum(axis=1)
        diffs = np.diff(points, axis=1).reshape(-1)
        return np.array(
            [
                points[np.argmin(sums)],
                points[np.argmin(diffs)],
                points[np.argmax(sums)],
                points[np.argmax(diffs)],
            ],
            dtype=np.float32,
        )

    @staticmethod
    def _save_debug_image(path: Path, array: np.ndarray) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        image = Image.fromarray(array)
        image.save(path)
        return path
