from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from io import BytesIO
from typing import Any

import cv2
import numpy as np
from PIL import Image, ImageOps

from .bootstrap import bootstrap_local_vendor

bootstrap_local_vendor()

try:  # noqa: E402
    from rapidocr_onnxruntime import RapidOCR
except ImportError:  # pragma: no cover
    RapidOCR = None

EXPIRATION_KEYWORDS = (
    "有效期",
    "有效期至",
    "失效期",
    "失效日期",
    "截止日期",
    "exp",
    "expiry",
    "useby",
    "use before",
    "best before",
    "valid until",
)

PRODUCTION_KEYWORDS = (
    "生产日期",
    "制造日期",
    "mfg",
    "mfd",
)


@dataclass(frozen=True)
class OCRLine:
    text: str
    score: float
    variant: str
    box: list[list[float]]


class ExpirationOCR:
    def __init__(self) -> None:
        self._engine = None

    def inspect(self, image_bytes: bytes) -> dict[str, Any]:
        if RapidOCR is None:
            return {
                "available": False,
                "engine": None,
                "message": "OCR 依赖未安装。",
                "expiration_date": None,
                "production_date": None,
                "matched_expiration_text": None,
                "matched_production_text": None,
                "date_candidates": [],
                "texts": [],
                "lines": [],
            }

        image = Image.open(BytesIO(image_bytes)).convert("RGB")
        lines = self._collect_lines(image)
        analysis = analyze_ocr_lines(lines)
        analysis["available"] = True
        analysis["engine"] = "rapidocr_onnxruntime"
        return analysis

    @property
    def engine(self):
        if self._engine is None:
            self._engine = RapidOCR()
        return self._engine

    def _collect_lines(self, image: Image.Image) -> list[OCRLine]:
        collected: dict[tuple[str, str], OCRLine] = {}
        for variant_name, variant_array in build_ocr_variants(image):
            raw_result, _ = self.engine(variant_array)
            if not raw_result:
                continue
            for line in normalize_ocr_result(raw_result, variant_name):
                key = (line.text, variant_name)
                previous = collected.get(key)
                if previous is None or line.score > previous.score:
                    collected[key] = line

        lines = list(collected.values())
        lines.sort(key=lambda item: (min(point[1] for point in item.box), min(point[0] for point in item.box)))
        return lines


def build_ocr_variants(image: Image.Image) -> list[tuple[str, np.ndarray]]:
    variants: list[tuple[str, np.ndarray]] = []
    for angle in (0, 90, 270):
        rotated = image.rotate(angle, expand=True).convert("RGB")
        rgb = np.asarray(rotated)
        gray = np.asarray(ImageOps.grayscale(rotated))
        enlarged_gray = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
        thresholded = cv2.threshold(
            enlarged_gray,
            0,
            255,
            cv2.THRESH_BINARY + cv2.THRESH_OTSU,
        )[1]
        variants.extend(
            [
                (f"rgb_{angle}", rgb),
                (f"gray2x_{angle}", enlarged_gray),
                (f"thresh2x_{angle}", thresholded),
            ]
        )
    return variants


def normalize_ocr_result(raw_result: list[list[Any]], variant: str) -> list[OCRLine]:
    lines: list[OCRLine] = []
    for item in raw_result:
        if len(item) < 3:
            continue
        box, text, score = item[0], str(item[1]).strip(), float(item[2])
        if not text:
            continue
        lines.append(
            OCRLine(
                text=text,
                score=score,
                variant=variant,
                box=[[float(x), float(y)] for x, y in box],
            )
        )
    return lines


def analyze_ocr_lines(lines: list[OCRLine]) -> dict[str, Any]:
    candidates = collect_date_candidates(lines)
    expiration_candidates = [candidate for candidate in candidates if candidate["kind"] == "expiration"]
    production_candidates = [candidate for candidate in candidates if candidate["kind"] == "production"]

    selected_expiration = select_best_candidate(expiration_candidates)
    selected_production = select_best_candidate(production_candidates)

    return {
        "message": build_ocr_message(selected_expiration, lines),
        "expiration_date": selected_expiration["date"] if selected_expiration else None,
        "production_date": selected_production["date"] if selected_production else None,
        "matched_expiration_text": selected_expiration["source_text"] if selected_expiration else None,
        "matched_production_text": selected_production["source_text"] if selected_production else None,
        "date_candidates": candidates,
        "texts": [line.text for line in lines],
        "lines": [
            {
                "text": line.text,
                "score": round(line.score, 4),
                "variant": line.variant,
                "box": line.box,
            }
            for line in lines
        ],
    }


def build_ocr_message(selected_expiration: dict[str, Any] | None, lines: list[OCRLine]) -> str:
    if selected_expiration:
        return f"OCR 命中有效期文本：{selected_expiration['source_text']}"
    if lines:
        return "OCR 已识别到部分文字，但没有找到可直接判定有效期的日期文本。"
    return "OCR 没有识别到清晰文字。"


def collect_date_candidates(lines: list[OCRLine]) -> list[dict[str, Any]]:
    seen: set[tuple[str, str, str]] = set()
    candidates: list[dict[str, Any]] = []
    combined_text = " ".join(line.text for line in lines)

    for line in lines:
        kind = classify_text_kind(line.text)
        for candidate_date in extract_dates_from_text(line.text, allow_short=kind is not None):
            candidate = {
                "kind": kind or "unknown",
                "date": candidate_date.isoformat(),
                "source_text": line.text,
                "score": round(line.score, 4),
                "variant": line.variant,
            }
            dedupe_key = (candidate["kind"], candidate["date"], candidate["source_text"])
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            candidates.append(candidate)

    combined_kind = classify_text_kind(combined_text)
    if combined_kind is not None:
        for candidate_date in extract_dates_from_text(combined_text, allow_short=True):
            candidate = {
                "kind": combined_kind,
                "date": candidate_date.isoformat(),
                "source_text": combined_text,
                "score": 0.0,
                "variant": "combined",
            }
            dedupe_key = (candidate["kind"], candidate["date"], candidate["source_text"])
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            candidates.append(candidate)

    candidates.sort(key=lambda item: (priority_for_kind(item["kind"]), -item["score"], item["date"]))
    return candidates


def classify_text_kind(text: str) -> str | None:
    normalized = normalize_text(text)
    if any(keyword in normalized for keyword in EXPIRATION_KEYWORDS):
        return "expiration"
    if any(keyword in normalized for keyword in PRODUCTION_KEYWORDS):
        return "production"
    return None


def extract_dates_from_text(text: str, allow_short: bool = False) -> list[date]:
    normalized = normalize_text(text)
    found: list[date] = []

    patterns = [
        re.compile(r"(?<!\d)(20\d{2}|19\d{2})[./\-年](\d{1,2})[./\-月](\d{1,2})日?(?!\d)"),
        re.compile(r"(?<!\d)(20\d{2})(\d{2})(\d{2})(?!\d)"),
    ]
    if allow_short:
        patterns.append(re.compile(r"(?<!\d)(\d{2})(\d{2})(\d{2})(?!\d)"))

    for pattern in patterns:
        for match in pattern.finditer(normalized):
            parsed = parse_date_parts(*match.groups())
            if parsed is not None and parsed not in found:
                found.append(parsed)

    return found


def parse_date_parts(year_text: str, month_text: str, day_text: str) -> date | None:
    year = 2000 + int(year_text) if len(year_text) == 2 else int(year_text)
    month = int(month_text)
    day = int(day_text)
    if year < 2000 or year > 2099:
        return None
    try:
        return date(year, month, day)
    except ValueError:
        return None


def normalize_text(text: str) -> str:
    normalized = text.strip().lower()
    normalized = normalized.replace(" ", "")
    normalized = normalized.replace("：", ":")
    normalized = normalized.replace("—", "-")
    normalized = normalized.replace("–", "-")
    normalized = normalized.replace("_", "-")
    normalized = normalized.replace("o", "0")
    return normalized


def select_best_candidate(candidates: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not candidates:
        return None
    sorted_candidates = sorted(
        candidates,
        key=lambda item: (
            priority_for_kind(item["kind"]),
            -item["score"],
            item["variant"] != "combined",
        ),
    )
    return sorted_candidates[0]


def priority_for_kind(kind: str) -> int:
    if kind == "expiration":
        return 0
    if kind == "production":
        return 1
    return 2
