from __future__ import annotations

import calendar
import re
from dataclasses import dataclass
from datetime import date

GROUP_SEPARATOR = "\x1d"


@dataclass(frozen=True)
class AISpec:
    name: str
    fixed_length: int | None = None
    max_length: int | None = None

    @property
    def is_fixed(self) -> bool:
        return self.fixed_length is not None


AI_SPECS: dict[str, AISpec] = {
    "00": AISpec(name="sscc", fixed_length=18),
    "01": AISpec(name="gtin", fixed_length=14),
    "10": AISpec(name="lot", max_length=20),
    "11": AISpec(name="production_date", fixed_length=6),
    "13": AISpec(name="packaging_date", fixed_length=6),
    "15": AISpec(name="best_before_date", fixed_length=6),
    "17": AISpec(name="expiration_date", fixed_length=6),
    "21": AISpec(name="serial", max_length=20),
    "240": AISpec(name="additional_product_id", max_length=30),
    "241": AISpec(name="customer_part_number", max_length=30),
}


def normalize_gs1_text(raw_code: str) -> str:
    normalized = raw_code.strip()
    for token in ("<GS>", "[GS]", "{GS}", "\\x1d"):
        normalized = normalized.replace(token, GROUP_SEPARATOR)
    return normalized


def parse_gs1_datamatrix(raw_code: str) -> dict[str, str]:
    normalized = normalize_gs1_text(raw_code)
    bracketed = _parse_bracketed(normalized)
    if bracketed:
        return bracketed
    return _parse_linear(normalized)


def to_friendly_fields(ai_values: dict[str, str]) -> dict[str, str]:
    friendly: dict[str, str] = {}
    for ai, value in ai_values.items():
        spec = AI_SPECS.get(ai)
        friendly[spec.name if spec else ai] = value
    return friendly


def extract_expiration_date(ai_values: dict[str, str]) -> date | None:
    expiration_value = ai_values.get("17")
    if not expiration_value:
        return None
    return parse_gs1_date(expiration_value)


def parse_gs1_date(value: str) -> date:
    if len(value) != 6 or not value.isdigit():
        raise ValueError(f"Invalid GS1 date: {value}")

    year = 2000 + int(value[:2])
    month = int(value[2:4])
    day = int(value[4:6])
    if not 1 <= month <= 12:
        raise ValueError(f"Invalid GS1 month: {value}")
    if day == 0:
        day = calendar.monthrange(year, month)[1]
    return date(year, month, day)


def _parse_bracketed(raw_code: str) -> dict[str, str]:
    matches = re.findall(r"\((\d{2,4})\)([^()]+)", raw_code)
    if not matches:
        return {}
    return {ai: value.strip() for ai, value in matches}


def _parse_linear(raw_code: str) -> dict[str, str]:
    values: dict[str, str] = {}
    index = 0
    while index < len(raw_code):
        if raw_code[index] == GROUP_SEPARATOR:
            index += 1
            continue

        ai = _match_ai(raw_code, index)
        if not ai:
            break

        spec = AI_SPECS[ai]
        data_start = index + len(ai)
        if spec.is_fixed:
            assert spec.fixed_length is not None
            data_end = data_start + spec.fixed_length
            field_value = raw_code[data_start:data_end]
            if len(field_value) != spec.fixed_length:
                break
        else:
            assert spec.max_length is not None
            data_end = data_start
            while data_end < len(raw_code):
                if raw_code[data_end] == GROUP_SEPARATOR:
                    break
                if data_end - data_start >= spec.max_length:
                    break
                data_end += 1
            field_value = raw_code[data_start:data_end]

        values[ai] = field_value
        index = data_end
        if index < len(raw_code) and raw_code[index] == GROUP_SEPARATOR:
            index += 1

    return values


def _match_ai(raw_code: str, index: int) -> str | None:
    for size in (4, 3, 2):
        candidate = raw_code[index : index + size]
        if candidate in AI_SPECS:
            return candidate
    if index + 2 <= len(raw_code):
        candidate = raw_code[index : index + 2]
        if re.fullmatch(r"9\d", candidate):
            return candidate
    return None
