from __future__ import annotations

import os
import sys
from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def bootstrap_local_vendor() -> None:
    project_root = Path(__file__).resolve().parents[1]
    vendor_dir = project_root / ".vendor"
    if not vendor_dir.exists():
        return

    vendor_path = str(vendor_dir)
    if vendor_path not in sys.path:
        sys.path.insert(0, vendor_path)

    bin_dir = vendor_dir / "bin"
    if bin_dir.exists() and hasattr(os, "add_dll_directory"):
        os.add_dll_directory(str(bin_dir))
