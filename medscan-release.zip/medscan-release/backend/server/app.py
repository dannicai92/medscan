from __future__ import annotations

import uuid
from contextlib import asynccontextmanager
from datetime import date
from typing import Any

from .bootstrap import bootstrap_local_vendor

bootstrap_local_vendor()

import starlette.requests
import asyncio
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from .config import settings
from .database import MedicineRepository
from .datamatrix import DataMatrixDecoder
from .scan_service import ScanService

try:
    from multipart.multipart import parse_options_header
except ImportError:  # pragma: no cover
    try:
        from python_multipart.multipart import parse_options_header
    except ImportError:  # pragma: no cover
        parse_options_header = None

if parse_options_header is not None and getattr(starlette.requests, "parse_options_header", None) is None:
    starlette.requests.parse_options_header = parse_options_header


class MedicineCreate(BaseModel):
    medicine_name: str = Field(..., description="药品名称")
    expiration_date: date = Field(..., description="有效期，格式 YYYY-MM-DD")
    raw_code: str | None = Field(default=None, description="完整追溯码")
    gtin: str | None = Field(default=None, description="商品码 AI(01)")
    lot: str | None = Field(default=None, description="批号 AI(10)")
    serial: str | None = Field(default=None, description="序列号 AI(21)")
    manufacturer: str | None = Field(default=None, description="生产厂家")
    notes: str | None = Field(default=None, description="备注")


class MedicineResponse(MedicineCreate):
    id: int
    created_at: str

    model_config = ConfigDict(from_attributes=True)


class TraceCodeRequest(BaseModel):
    trace_code: str = Field(..., description="ESP32 识别或扫码得到的追溯码")
    device_id: str | None = Field(default=None, description="设备编号")


def build_repository() -> MedicineRepository:
    return MedicineRepository(settings.database_path)


def build_decoder() -> DataMatrixDecoder:
    return DataMatrixDecoder()


class ConnectionManager:
    def __init__(self):
        self.active = []
    async def connect(self, ws):
        await ws.accept()
        self.active.append(ws)
    def disconnect(self, ws):
        if ws in self.active:
            self.active.remove(ws)
    async def broadcast(self, message):
        import json
        dead = []
        for ws in self.active:
            try:
                await ws.send_text(json.dumps(message, ensure_ascii=False))
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)

manager = ConnectionManager()
repository = build_repository()
scan_service = ScanService(repository=repository, decoder=build_decoder())


@asynccontextmanager
async def lifespan(_: FastAPI):
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    settings.reports_dir.mkdir(parents=True, exist_ok=True)
    settings.debug_dir.mkdir(parents=True, exist_ok=True)
    repository.init_database()
    yield


app = FastAPI(
    title="ESP32 药箱图片识别服务",
    version="1.0.0",
    lifespan=lifespan,
)


app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
async def health_check() -> dict[str, Any]:
    return {
        "ok": True,
        "service": "medicine-trace-server",
        "database": str(repository.database_path),
        "reports": str(settings.reports_dir),
    }


@app.post("/api/v1/medicines", response_model=MedicineResponse)
async def create_medicine(payload: MedicineCreate) -> dict[str, Any]:
    return repository.create_medicine(payload.model_dump(mode="json"))


@app.get("/api/v1/medicines", response_model=list[MedicineResponse])
async def list_medicines(limit: int = 100) -> list[dict[str, Any]]:
    return repository.list_medicines(limit=min(limit, 500))


@app.delete("/api/v1/medicines/{medicine_id}")
async def delete_medicine(medicine_id: int):
    deleted = repository.delete_medicine(medicine_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"药品 {medicine_id} 不存在")
    return {"ok": True, "deleted_id": medicine_id}


@app.get("/api/v1/scans")
async def list_scan_records(limit: int = 100) -> list[dict[str, Any]]:
    return repository.list_scan_records(limit=min(limit, 500))


@app.post("/api/v1/trace-code")
async def submit_trace_code(payload: TraceCodeRequest) -> JSONResponse:
    status_code, response_payload = scan_service.analyze(
        image_bytes=b"",
        original_filename="manual-code.txt",
        device_id=payload.device_id,
        manual_code=payload.trace_code,
        save_upload=False,
    )
    return JSONResponse(status_code=status_code, content=response_payload)


@app.post("/api/v1/upload")
async def upload_image(request: Request) -> JSONResponse:
    content_type = request.headers.get("content-type", "")
    device_id = request.headers.get("x-device-id")
    manual_code = request.headers.get("x-manual-code")
    upload_filename = f"{uuid.uuid4().hex}{guess_suffix_from_content_type(content_type)}"

    if content_type.startswith("multipart/form-data"):
        form = await request.form()
        file = form.get("image")
        if file is None:
            raise HTTPException(status_code=400, detail="multipart 请求缺少 image 字段")
        image_bytes = await file.read()
        upload_filename = getattr(file, "filename", upload_filename) or upload_filename
        device_id = str(form.get("device_id") or device_id or "") or None
        manual_code = str(form.get("manual_code") or manual_code or "") or None
    else:
        image_bytes = await request.body()

    status_code, response_payload = scan_service.analyze(
        image_bytes=image_bytes,
        original_filename=upload_filename,
        device_id=device_id,
        manual_code=manual_code,
    )
    # 识别成功后广播给 WebSocket 客户端
    if response_payload.get("ok") and response_payload.get("status") in ("valid", "expired", "unknown"):
        import asyncio as _asyncio
        _asyncio.ensure_future(manager.broadcast({
            "action":         "take_out",
            "name":           response_payload.get("medicine_name") or response_payload.get("raw_code") or "未知药品",
            "expiry_date":    response_payload.get("expiration_date"),
            "box_id":         1,
            "status":         response_payload.get("status"),
            "days_remaining": response_payload.get("days_remaining"),
        }))
    return JSONResponse(status_code=status_code, content=response_payload)


def guess_suffix_from_content_type(content_type: str) -> str:
    lowered = content_type.lower()
    if "jpeg" in lowered or "jpg" in lowered:
        return ".jpg"
    if "png" in lowered:
        return ".png"
    if "webp" in lowered:
        return ".webp"
    return ".bin"


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True:
            await asyncio.wait_for(ws.receive_text(), timeout=30)
    except (WebSocketDisconnect, asyncio.TimeoutError, Exception):
        manager.disconnect(ws)
