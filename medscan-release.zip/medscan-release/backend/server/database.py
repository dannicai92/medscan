from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import date, datetime
from pathlib import Path
from typing import Any


class MedicineRepository:
    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path

    @contextmanager
    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def init_database(self) -> None:
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS medicines (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    medicine_name TEXT NOT NULL,
                    raw_code TEXT,
                    gtin TEXT,
                    lot TEXT,
                    serial TEXT,
                    expiration_date TEXT NOT NULL,
                    manufacturer TEXT,
                    notes TEXT,
                    created_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS scan_records (
                    id TEXT PRIMARY KEY,
                    device_id TEXT,
                    raw_code TEXT,
                    upload_path TEXT,
                    status TEXT NOT NULL,
                    expiration_date TEXT,
                    payload_json TEXT NOT NULL,
                    message TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_medicines_code
                ON medicines(raw_code)
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_medicines_gtin_lot_serial
                ON medicines(gtin, lot, serial)
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_scan_records_created_at
                ON scan_records(created_at)
                """
            )

    def create_medicine(self, payload: dict[str, Any]) -> dict[str, Any]:
        created_at = datetime.utcnow().isoformat(timespec="seconds")
        with self.connect() as connection:
            cursor = connection.execute(
                """
                INSERT INTO medicines (
                    medicine_name,
                    raw_code,
                    gtin,
                    lot,
                    serial,
                    expiration_date,
                    manufacturer,
                    notes,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    payload["medicine_name"],
                    payload.get("raw_code"),
                    payload.get("gtin"),
                    payload.get("lot"),
                    payload.get("serial"),
                    payload["expiration_date"],
                    payload.get("manufacturer"),
                    payload.get("notes"),
                    created_at,
                ),
            )
            medicine_id = cursor.lastrowid
        return self.get_medicine(medicine_id)

    def get_medicine(self, medicine_id: int) -> dict[str, Any]:
        with self.connect() as connection:
            row = connection.execute(
                "SELECT * FROM medicines WHERE id = ?",
                (medicine_id,),
            ).fetchone()
        if row is None:
            raise KeyError(f"Medicine {medicine_id} not found")
        return self._row_to_dict(row)

    def delete_medicine(self, medicine_id: int) -> bool:
        with self.connect() as connection:
            cursor = connection.execute(
                "DELETE FROM medicines WHERE id = ?",
                (medicine_id,),
            )
        return cursor.rowcount > 0

    def list_medicines(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT *
                FROM medicines
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._row_to_dict(row) for row in rows]

    def find_medicine(
        self,
        raw_code: str | None = None,
        gtin: str | None = None,
        lot: str | None = None,
        serial: str | None = None,
    ) -> dict[str, Any] | None:
        if raw_code:
            with self.connect() as connection:
                row = connection.execute(
                    """
                    SELECT *
                    FROM medicines
                    WHERE raw_code = ?
                    ORDER BY id DESC
                    LIMIT 1
                    """,
                    (raw_code,),
                ).fetchone()
            if row is not None:
                return self._row_to_dict(row)

        if not gtin:
            return None

        query = """
            SELECT *
            FROM medicines
            WHERE gtin = ?
        """
        params: list[Any] = [gtin]
        if lot:
            query += " AND lot = ?"
            params.append(lot)
        if serial:
            query += " AND serial = ?"
            params.append(serial)
        query += " ORDER BY id DESC LIMIT 1"

        with self.connect() as connection:
            row = connection.execute(query, params).fetchone()
        return self._row_to_dict(row) if row is not None else None

    def log_scan(
        self,
        *,
        device_id: str | None,
        raw_code: str | None,
        upload_path: str | None,
        status: str,
        expiration_date: date | None,
        payload: dict[str, Any],
        message: str,
    ) -> str:
        record_id = uuid.uuid4().hex
        created_at = datetime.utcnow().isoformat(timespec="seconds")
        with self.connect() as connection:
            connection.execute(
                """
                INSERT INTO scan_records (
                    id,
                    device_id,
                    raw_code,
                    upload_path,
                    status,
                    expiration_date,
                    payload_json,
                    message,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record_id,
                    device_id,
                    raw_code,
                    upload_path,
                    status,
                    expiration_date.isoformat() if expiration_date else None,
                    json.dumps(payload, ensure_ascii=False),
                    message,
                    created_at,
                ),
            )
        return record_id

    def list_scan_records(self, limit: int = 100) -> list[dict[str, Any]]:
        with self.connect() as connection:
            rows = connection.execute(
                """
                SELECT *
                FROM scan_records
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._scan_row_to_dict(row) for row in rows]

    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
        payload = dict(row)
        return payload

    @staticmethod
    def _scan_row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
        payload = dict(row)
        payload["payload_json"] = json.loads(payload["payload_json"])
        return payload
