from server.bootstrap import bootstrap_local_vendor

bootstrap_local_vendor()

from server.app import app
from server.config import settings


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host=settings.host,
        port=settings.port,
    )
