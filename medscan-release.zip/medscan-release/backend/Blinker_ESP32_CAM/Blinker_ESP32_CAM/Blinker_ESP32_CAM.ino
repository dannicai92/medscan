#include <WiFi.h>
#include <HTTPClient.h>
#include "ESP32_CAM_SERVER.h"

char ssid[] = "902";
char pswd[] = "123456789";

const char * deviceId = "esp32-cam-01";
const char * uploadUrl = "http://192.168.1.100:8000/api/v1/upload";

bool cameraReady = false;
bool uploadedOnce = false;
uint32_t lastUploadAttemptMs = 0;
const uint32_t uploadRetryIntervalMs = 10000;

void connectWiFi()
{
    if (WiFi.status() == WL_CONNECTED) {
        return;
    }

    Serial.print("Connecting WiFi");
    WiFi.begin(ssid, pswd);

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    Serial.println();
    Serial.println("WiFi connected");
    Serial.println("IP: " + WiFi.localIP().toString());
}

void ensureCameraReady()
{
    if (cameraReady) {
        return;
    }

    if (setupCamera()) {
        cameraReady = true;
        Serial.println("Camera init success");
        Serial.println("Local snapshot URL: http://" + WiFi.localIP().toString() + "/jpg");
        return;
    }

    Serial.println("Camera setup failed, will retry");
}

bool captureJpeg(camera_fb_t *& fb)
{
    fb = nullptr;

    if (!cameraReady) {
        Serial.println("Capture skipped: camera not ready");
        return false;
    }

    // Discard a stale frame before taking the upload snapshot.
    camera_fb_t * stale = esp_camera_fb_get();
    if (stale) {
        esp_camera_fb_return(stale);
        delay(60);
    }

    fb = esp_camera_fb_get();
    if (!fb) {
        Serial.println("Camera capture failed");
        return false;
    }

    if (fb->format != PIXFORMAT_JPEG) {
        Serial.println("Camera frame is not JPEG");
        esp_camera_fb_return(fb);
        fb = nullptr;
        return false;
    }

    return true;
}

bool uploadSnapshot()
{
    camera_fb_t * fb = nullptr;
    if (!captureJpeg(fb)) {
        return false;
    }

    HTTPClient http;
    http.begin(uploadUrl);
    http.addHeader("Content-Type", "image/jpeg");
    http.addHeader("X-Device-Id", deviceId);

    Serial.println("Uploading snapshot...");
    int httpCode = http.POST(fb->buf, fb->len);
    String response = http.getString();

    esp_camera_fb_return(fb);
    fb = nullptr;

    Serial.print("HTTP code: ");
    Serial.println(httpCode);
    Serial.println("HTTP response:");
    Serial.println(response);

    http.end();

    return httpCode > 0 && httpCode < 300;
}

void setup()
{
    Serial.begin(115200);
    Serial.println("HTTP-UPLOAD BUILD");

    connectWiFi();
    ensureCameraReady();
}

void loop()
{
    connectWiFi();
    ensureCameraReady();

    if (uploadedOnce) {
        return;
    }

    if (millis() - lastUploadAttemptMs < uploadRetryIntervalMs) {
        delay(50);
        return;
    }

    lastUploadAttemptMs = millis();

    if (uploadSnapshot()) {
        uploadedOnce = true;
        Serial.println("Snapshot upload succeeded");
    } else {
        Serial.println("Snapshot upload failed, will retry");
    }
}
