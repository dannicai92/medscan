============================
MedScan S · 快速启动指南
============================

【后端启动】（在后端同伴的电脑上）
  cd backend
  python main.py
  服务启动在 http://0.0.0.0:8000

查本机 IP：
  Windows: ipconfig  →  找 192.168.x.x
  Mac:     ifconfig  →  找 192.168.x.x

【前端接入】
  打开 miniprogram/utils/api.js 第8行：
  BASE_URL: 'http://192.168.x.x:8000',

【本次新增接口】
  DELETE /api/v1/medicines/{id}   → 删除药品
  WS     ws://IP:8000/ws          → WebSocket 实时推送

【所有接口】
  GET    /health
  GET    /api/v1/medicines
  POST   /api/v1/medicines
  DELETE /api/v1/medicines/{id}
  GET    /api/v1/scans
  POST   /api/v1/upload
  WS     /ws
